package com.example.actividadlabcorte2.ui.home;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.actividadlabcorte2.Interface.JsonPlaceHolderAPI;
import com.example.actividadlabcorte2.R;
import com.example.actividadlabcorte2.ui.slideshow.CustomAdapterArchivo;


import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HomeFragment extends Fragment {

    private HomeViewModel homeViewModel;
    private List<Posts> postsList;
    private RecyclerView recyclerViewPosts;
    private CustomAdapterPosts customAdapterPosts;
    private CardView cardView;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerViewPosts = (RecyclerView) root.findViewById(R.id.RecyclerViewPosts);
        recyclerViewPosts.setLayoutManager(new LinearLayoutManager(root.getContext()));
        CardView cardView = (CardView) root.findViewById(R.id.cardViewPosts);
        //postsList = new ArrayList<>();
        //final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {


                System.out.println(" ------------------ " + URL);
                Retrofit retrofit = new Retrofit.Builder()
                        .addConverterFactory(GsonConverterFactory.create())
                        .baseUrl(URL)
                        .build();

                JsonPlaceHolderAPI jsonPlaceHolderAPI = retrofit.create(JsonPlaceHolderAPI.class);

                Call<List<Posts>> call = jsonPlaceHolderAPI.getPost();

                call.enqueue(new Callback<List<Posts>>() {
                    @Override
                    public void onResponse(Call<List<Posts>> call, Response<List<Posts>> response) {
                        System.out.println(response);
                        if(!response.isSuccessful()){
                            Toast.makeText(root.getContext(),"Codigo: " + response.code(),Toast.LENGTH_SHORT).show();
                            return;
                        }

                        List<Posts> postsList2 = response.body();
                        String content = "";
                        System.out.println(response.body().get(0).getDepa_nombre());
                        System.out.println(postsList2.size());

                        customAdapterPosts = new CustomAdapterPosts(postsList2);
                        recyclerViewPosts.setAdapter(customAdapterPosts);

                    }

                    @Override
                    public void onFailure(Call<List<Posts>> call, Throwable t) {
                        System.out.println(t);
                    }
                });


                //textView.setText(s);
            }
        });
        return root;
    }

    private final String URL = "https://www.datos.gov.co/resource/";

    private void obtenerPosts(View root){

        System.out.println(URL);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(URL)
                .build();

        JsonPlaceHolderAPI jsonPlaceHolderAPI = retrofit.create(JsonPlaceHolderAPI.class);

        Call<List<Posts>> call = jsonPlaceHolderAPI.getPost();

        call.enqueue(new Callback<List<Posts>>() {
            @Override
            public void onResponse(Call<List<Posts>> call, Response<List<Posts>> response) {
                System.out.println(response);
                if(!response.isSuccessful()){
                    Toast.makeText(root.getContext(),"Codigo: " + response.code(),Toast.LENGTH_SHORT).show();
                    return;
                }

                postsList = response.body();
                String content = "";
                for(Posts post: postsList){

                    content += "" + post.getDepa_nombre();
                }
                System.out.println(content);

            }

            @Override
            public void onFailure(Call<List<Posts>> call, Throwable t) {
                System.out.println(t);
            }
        });

    }

}