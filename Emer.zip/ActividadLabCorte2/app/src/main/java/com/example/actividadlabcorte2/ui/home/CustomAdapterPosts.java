package com.example.actividadlabcorte2.ui.home;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.actividadlabcorte2.R;

import java.util.List;

public class CustomAdapterPosts extends RecyclerView.Adapter<CustomAdapterPosts.ViewHolder> {

    public static class ViewHolder extends RecyclerView.ViewHolder{
        private TextView muni_nombre;
        private TextView  sede_nombre;
        private TextView  direccion;
        private TextView  telefono;


        public ViewHolder(View view) {
            super(view);

            muni_nombre = (TextView) view.findViewById(R.id.textMuni_nombre);
            sede_nombre = (TextView) view.findViewById(R.id.textSede_nombre);
            direccion = (TextView) view.findViewById(R.id.textDireccion);
            telefono = (TextView) view.findViewById(R.id.textTelefono);

        }
    }

    List<Posts> postsList;

    public CustomAdapterPosts(List<Posts> list){
        postsList = list;
    }

    @NonNull
    @Override
    public CustomAdapterPosts.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.post,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapterPosts.ViewHolder holder, int position) {
        Posts infoPosts = postsList.get(position);
        holder.muni_nombre.setText(postsList.get(position).getMuni_nombre());
        holder.sede_nombre.setText(postsList.get(position).getSede_nombre());
        holder.direccion.setText(postsList.get(position).getDireccion());
        holder.telefono.setText(postsList.get(position).getTelefono());

    }

    @Override
    public int getItemCount() {
        return postsList.size();
    }
}
